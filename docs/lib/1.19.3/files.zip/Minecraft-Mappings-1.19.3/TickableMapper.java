package @package@;

public interface TickableMapper {

	void tick();
}
