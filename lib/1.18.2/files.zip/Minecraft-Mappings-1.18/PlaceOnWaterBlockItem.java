package @package@;

import net.minecraft.world.item.WaterLilyBlockItem;
import net.minecraft.world.level.block.Block;

public class PlaceOnWaterBlockItem extends WaterLilyBlockItem {

	public PlaceOnWaterBlockItem(Block block, Properties properties) {
		super(block, properties);
	}
}
