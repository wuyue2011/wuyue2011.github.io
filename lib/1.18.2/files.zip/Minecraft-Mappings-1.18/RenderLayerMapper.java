package @package@;

import net.minecraft.client.renderer.RenderType;

public abstract class RenderLayerMapper extends RenderType {

	public RenderLayerMapper() {
		super(null, null, null, 0, false, false, null, null);
	}
}
