package @package@;

import net.minecraft.client.gui.components.Widget;

public interface WidgetMapper extends Widget {
}
